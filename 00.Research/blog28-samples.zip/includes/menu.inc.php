<nav>
	<ul id="menu">
		<li><a href="/">Home</a></li>
		<li><a href="/contact/index">Contact</a></li>
	</ul>
</nav>